This repository contains firmware for download to wireless things radio devices to configure the device for a specific function.
Please look in the folder for your device.

To download select the firmware you are interested to view the binary file and then (depending on your browser) press the RAW button (upper right hand of the text) or right click on the raw button and select 'save link as'.
You can download the files for all devices by clicking on the "Zip" link

Release notes can be found at the OpenMicros site
http://openmicros.org/index.php/articles/84-xrf-basics/224-firmware-release-notes

**Each folder may have mutiple version of the same firmware, always use the latest unless asked to use an older version by support.**

