This repository contains JSON file used by the WirelessThings Device configuration wizard to configure Language of Things devices
